data real
INSERT INTO JENIS_MKS(Id, NamaMKS) VALUES (1, 'Skripsi');
INSERT INTO JENIS_MKS(Id, NamaMKS) VALUES (2, 'Karya Akhir');
INSERT INTO JENIS_MKS(Id, NamaMKS) VALUES (3, 'Proposal Tesis');
INSERT INTO JENIS_MKS(Id, NamaMKS) VALUES (4, 'Usulan Penelitian');
INSERT INTO JENIS_MKS(Id, NamaMKS) VALUES (5, 'Seminar Hasil Penelitian S3');
INSERT INTO JENIS_MKS(Id, NamaMKS) VALUES (6, 'Pra Promosi');
INSERT INTO JENIS_MKS(Id, NamaMKS) VALUES (7, 'Promosi');
INSERT INTO JENIS_MKS(Id, NamaMKS) VALUES (8, 'Tesis');
INSERT INTO JENIS_MKS(Id, NamaMKS) VALUES (9, 'Tugas Akhir');