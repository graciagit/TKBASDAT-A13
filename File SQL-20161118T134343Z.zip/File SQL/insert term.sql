data real
INSERT INTO TERM (Tahun, Semester) VALUES (2015, 1);
INSERT INTO TERM (Tahun, Semester) VALUES (2015, 2);
INSERT INTO TERM (Tahun, Semester) VALUES (2016, 1);
INSERT INTO TERM (Tahun, Semester) VALUES (2016, 2);