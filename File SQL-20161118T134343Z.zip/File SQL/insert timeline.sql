data real
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (1, 'Upload berkas skripsi', '2015/05/13', 2015, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (2, 'Upload final berkas skripsi', '2015/05/23', 2015, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (3, 'Upload berkas skripsi', '2015/12/19', 2015, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (4, 'Upload final berkas skripsi', '2015/12/22', 2015, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (5, 'Upload berkas telat skripsi', '2015/12/23', 2015, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (6, 'Upload berkas skripsi', '2016/04/29', 2016, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (7, 'Upload final berkas skripsi', '2016/04/30', 2016, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (8, 'Upload berkas telat skripsi', '2016/05/01', 2016, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (9, 'Upload berkas skripsi', '2016/12/20', 2016, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (10, 'Upload final berkas skripsi', '2016/12/29', 2016, 1);



data random
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (11, 'Upload berkas tesis', '2015/05/11', 2015, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (12, 'Upload final berkas tesis', '2015/05/18', 2015, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (13, 'Upload berkas tesis', '2015/12/02', 2015, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (14, 'Upload final berkas tesis', '2015/12/09', 2015, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (15, 'Upload berkas telat tesis', '2015/12/22', 2015, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (16, 'Upload berkas tesis', '2016/04/01', 2016, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (17, 'Upload final berkas tesis', '2016/04/08', 2016, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (18, 'Upload berkas telat tesis', '2016/05/20', 2016, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (19, 'Upload berkas tesis', '2016/12/22', 2016, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (20, 'Upload final berkas tesis', '2016/12/30', 2016, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (21, 'Upload berkas karya akhir', '2015/05/25', 2015, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (22, 'Upload final berkas karya akhir', '2015/05/31', 2015, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (23, 'Upload berkas karya akhir', '2015/12/01', 2015, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (24, 'Upload final berkas karya akhir', '2015/12/18', 2015, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (25, 'Upload berkas telat karya akhir', '2015/12/24', 2015, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (26, 'Upload berkas karya akhir', '2016/04/02', 2016, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (27, 'Upload final berkas karya akhir', '2016/04/09', 2016, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (28, 'Upload berkas telat karya akhir', '2016/05/22', 2016, 2);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (29, 'Upload berkas karya akhir', '2016/12/24', 2016, 1);
INSERT INTO TIMELINE(IdTimeline, NamaEvent, Tanggal, Tahun, Semester) VALUES (30, 'Upload final berkas karya akhir', '2016/12/31', 2016, 1);