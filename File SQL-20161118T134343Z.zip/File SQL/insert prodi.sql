data real
INSERT INTO PRODI (Id, NamaProdi) VALUES (111, 'Ilmu Komputer');
INSERT INTO PRODI (Id, NamaProdi) VALUES (112, 'Sistem Informasi');
INSERT INTO PRODI (Id, NamaProdi) VALUES (211, 'Ilmu Geologi');
INSERT INTO PRODI (Id, NamaProdi) VALUES (311, 'Teknik Perkapalan');
INSERT INTO PRODI (Id, NamaProdi) VALUES (312, 'Teknik Planalogi');
INSERT INTO PRODI (Id, NamaProdi) VALUES (411, 'Ilmu Kedokteran');