data real
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (1, '3.111 (Depok)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (2, '3.112 (Depok)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (3, '3.113 (Depok)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (4, '3.114 (Depok)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (5, '3.115 (Depok)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (6, '1A (Salemba)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (7, '1B (Salemba)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (8, '1C (Salemba)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (9, '1D (Salemba)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (10, '2A (Salemba)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (11, '2B (Salemba)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (12, '2C (Salemba)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (13, '2D (Salemba)');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (14, 'Rapat Kecil');										
INSERT INTO RUANGAN (IdRuangan, NamaRuangan) VALUES (15, 'Rapat Sedang');										
										
										
data random										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (16, '3.116 (Depok)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (17, '3.117 (Depok)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (18, '3.118 (Depok)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (19, '3.119 (Depok)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (20, '3.120 (Depok)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (21, '3A (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (22, '3B (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (23, '3C (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (24, '3D (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (25, '4A (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (26, '4B (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (27, '4C (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (28, '4D (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (29, '5A (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (30, '5B (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (31, '5C (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (32, '5D (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (33, '6A (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (34, '6B (Salemba)');										
INSERT INTO RUANGAN (IDRuangan, NamaRuangan) VALUES (35, '6C (Salemba)');										